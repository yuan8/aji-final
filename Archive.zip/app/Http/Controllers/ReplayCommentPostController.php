<?php

namespace App\Http\Controllers;

use App\ReplayCommentPost;
use Illuminate\Http\Request;

class ReplayCommentPostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ReplayCommentPost  $replayCommentPost
     * @return \Illuminate\Http\Response
     */
    public function show(ReplayCommentPost $replayCommentPost)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ReplayCommentPost  $replayCommentPost
     * @return \Illuminate\Http\Response
     */
    public function edit(ReplayCommentPost $replayCommentPost)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ReplayCommentPost  $replayCommentPost
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ReplayCommentPost $replayCommentPost)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ReplayCommentPost  $replayCommentPost
     * @return \Illuminate\Http\Response
     */
    public function destroy(ReplayCommentPost $replayCommentPost)
    {
        //
    }
}
