<?php

namespace App\Http\Controllers;

use App\PostTags;
use Illuminate\Http\Request;

class PostTagsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PostTags  $postTags
     * @return \Illuminate\Http\Response
     */
    public function show(PostTags $postTags)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PostTags  $postTags
     * @return \Illuminate\Http\Response
     */
    public function edit(PostTags $postTags)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PostTags  $postTags
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PostTags $postTags)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PostTags  $postTags
     * @return \Illuminate\Http\Response
     */
    public function destroy(PostTags $postTags)
    {
        //
    }
}
