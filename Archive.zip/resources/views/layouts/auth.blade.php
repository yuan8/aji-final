<!DOCTYPE html>
<html>
<head>
    @include('component.header-auth')

    @yield('css')
</head>
<body>

    @yield('content')

</body>

    @yield('js')

</html>