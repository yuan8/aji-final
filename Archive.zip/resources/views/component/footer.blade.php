<footer class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <a href="about.html">About</a> - <a href="privacy.html">Term &amp; Privacy Policy</a>
          </div>
          <div class="col-md-6">
            <span class="pull-right">Copyright © 2017 AJI Indonesia - All rights reserved</span>
          </div>
        </div>
      </div>
</footer>