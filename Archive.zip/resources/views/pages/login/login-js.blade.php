<script type="text/javascript">
	
	
function Login(){
	Link="{{url('home')}}";
	VisiteLink(Link);
}

	
</script>