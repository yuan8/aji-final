<!DOCTYPE html>
<html>
<head>
    <?php echo $__env->make('component.header-auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>

    <?php echo $__env->yieldContent('content'); ?>

</body>

    <?php echo $__env->yieldContent('js'); ?>

</html>