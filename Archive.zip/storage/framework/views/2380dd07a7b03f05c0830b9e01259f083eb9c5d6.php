<!-- post -->
<div class="box box-widget box-timeline" id="postStatus2" post-id="2" post-url="">
  <div class="box-header with-border">
    <div class="user-block">
      <?php if($post->fromUser->profile_photo==''): ?>
      <img class="img-circle" src="<?php echo e(asset('aji/component/img/Friends/guy-3.jpg')); ?>" alt="User Image">
      <?php else: ?>
      <img class="img-circle" src="<?php echo e(asset($post->fromUser->profile_photo)); ?>" alt="User Image">

      <?php endif; ?>
      <span class="username">
        <a href="<?php echo e(url('/user/'.$post->FromUser->id.'/show/timeline')); ?>"><?php echo e($post->FromUser->name); ?></a>
      </span>

      <span class="description">

        <span class=""><?php echo e(TimeG::gTime(Carbon\Carbon::parse($post->created_at)->diffForHumans())); ?></span> - 

        <?php if($post->kanal=='national'): ?>
        <a href="#">National</a></span>
        <?php elseif($post->kanal=='kota'): ?>
        <a href="#"><?php echo e($post->FromCity->name); ?></a></span>
        <?php endif; ?>

      </div>
      <div class="box-tools">
        <ul class="nav">
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
              <i class="fa fa-ellipsis-h" aria-hidden="true"></i>
            </a>
            <ul class="dropdown-menu">
              <li><a href="#">Make Sticky</a></li>
              <li class="divider"></li>
              <li><a href="#">Edit</a></li>
              <li><a href="#">Delete</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>

    <div class="box-body">
      <?php if(count($post->HavePostFilePictures)>1): ?>
      <div class="slider-in-post" >
        <ul class="bxslider">
          <?php $__currentLoopData = $post->HavePostFilePictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><div style="position: relative; max-height: 300px; overflow: hidden;">
            <img class="img-responsive pad" src="<?php echo e(url($picture->url)); ?>" alt="Photo" style=" ">
          </div></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
      <?php else: ?>
      <?php $__currentLoopData = $post->HavePostFilePictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div style="position: relative; max-height: 300px; overflow: hidden;">
        <img class="img-responsive pad" src="<?php echo e(url($picture->url)); ?>" alt="Photo" style=" ">
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endif; ?>
      
      <div id="post-content-preview-<?php echo e($post->id); ?>">
        <?php if(count($post->HavePostFilePictures) >0): ?>
        <p style="padding: 10px;" ><?php echo e(substr($post->content, 0, 430)); ?>

          <?php if(strlen($post->content)>430): ?>
          <a id="content-post-<?php echo e($post->id); ?>" class="more" onclick="moreContentPost(<?php echo e($post->id); ?>)" style="color: #777; font-size: 14px; font-weight: bold;" > . . . More </a>
          <?php endif; ?>
        </p>
        <?php else: ?>
        <p style="padding: 10px;"><?php echo e(substr($post->content, 0, 790)); ?>

          <?php if(strlen($post->content)>790): ?>
          <a id="content-post-<?php echo e($post->id); ?>" class="more" onclick="moreContentPost(<?php echo e($post->id); ?>)"   style="color: #777; font-size: 14px; font-weight: bold;" > . . . More</a>
          <?php endif; ?>
        </p>
        <?php endif; ?>
      </div>
      <div id="post-content-full-<?php echo e($post->id); ?>" class="animated fadeIn" style="display: none;">
        <p style="padding: 10px;"><?php echo e($post->content); ?></p>
      </div>

      <!-- <div class="attachment-block clearfix">
        <img class="attachment-img" src="<?php echo e(asset('aji/component/img/Photos/2.jpg')); ?>" alt="Attachment Image">
        <div class="attachment-pushed">
          <h5 class="attachment-heading">
            <a href="http://www.maskod.co.id.com/">Lorem ipsum text generator</a>
          </h5>
          <div class="attachment-text">
            Description about the attachment can be placed here.
            Lorem Ipsum is simply dummy text of the printing and typesetting industry... <a href="home.html#">more</a>
          </div>
        </div>
      </div> -->
      <?php if($post->me_like_count > 0): ?>
      <a class="btn btn-link btn-md active"  id="likePost-view-<?php echo e($post->id); ?>" onclick='likePostEvent(<?php echo e($post->id); ?>,"<?php echo e(url('api/v1/like')); ?>/")'>
        <i class="fa fa-heart"></i> Liked
      </a>
      <?php else: ?>
      <a class="btn btn-link btn-md"  id="likePost-view-<?php echo e($post->id); ?>" onclick='likePostEvent(<?php echo e($post->id); ?>,"<?php echo e(url('api/v1/like')); ?>/")'>
        <i class="fa fa-heart-o"></i> Like
      </a>
      <?php endif; ?>

      <a class="btn btn-link btn-md postComment" id="postComment2" post-id="2">
        <i class="fa fa-comment-o"></i> Comment
      </a>
      <a class="btn btn-default btn-link btn-md postShare" data-toggle="modal" data-target="#modal-share-post-<?php echo e($post->id); ?>">
        <i class="fa fa-share"></i> Share
      </a>
      <span class="pull-right text-muted">
        <a class="btn btn-default btn-link btn-md" data-toggle="modal" data-target="#modal-likes-<?php echo e($post->id); ?>">
          <span id="count-like-post-<?php echo e($post->id); ?>" ><?php echo e($post->like_count); ?></span> likes - <span id="count-comment-post-<?php echo e($post->id); ?>"><?php echo e($post->comment_count); ?></span> comments
        </a>
      </span>
    </div>

    <div class="box-footer box-comments" id="comment-place-post-<?php echo e($post->id); ?>" style="padding-bottom: 0;">
     <?php $__currentLoopData = $post->HavePostComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <?php if((count($post->HavePostComments) - $key)<=2): ?>
     <div class="box-comment comment-list-post-<?php echo e($post->id); ?>" >
      <?php else: ?>
      <div class="box-comment comment-list-post-<?php echo e($post->id); ?> comment-hidden animated fadeIn" style="display: none;">

        <?php endif; ?>

        <?php if($comment->fromUser->profile_photo==''): ?>
        <img class="img-circle img-sm" src="<?php echo e(asset('aji/component/img/Friends/guy-3.jpg')); ?>" alt="User Image">
        <?php else: ?>
        <img class="img-circle img-sm" src="<?php echo e(asset($comment->fromUser->profile_photo)); ?>" alt="User Image">

        <?php endif; ?>


        <div class="comment-text">
          <span class="username">
            <a href="<?php echo e(url('user/'.$comment->FromUser->id.'/show/timeline')); ?>"><?php echo e($comment->FromUser->name); ?></a>
            <a href="#"><span class="text-muted pull-right">x</span></a>
          </span>

          <p style="padding-right: 20px;" id="comment-content-preview-<?php echo e($comment->id); ?>">

            <?php echo e(substr($comment->content, 0, 200)); ?>

            <?php if(strlen($comment->content)>200): ?>
            <a id="content-post-<?php echo e($post->id); ?>" class="more" onclick="moreContentComment(<?php echo e($comment->id); ?>)"   style="color: #777; font-size: 14px; font-weight: bold;" > . . . More</a>
            <?php endif; ?>
          </p>
          <p style="padding-right:20px; display: none;" id="comment-content-full-<?php echo e($comment->id); ?>"><?php echo e($comment->content); ?></p>


          <div class="actionFooterPost">
            <span id="likeComment2-1" class="likeComment">Like</span>
            · 
            <span id="replyComment2-1" class="replyComment">Reply</span>
            · 
            <span class="likedComment">
              <span class="fa fa-heart-o"></span>0</span>
              · 

              <span class="text-muted"><?php echo e(TimeG::gTime(Carbon\Carbon::parse($comment->created_at)->diffForHumans())); ?></span>
              <div class="replyCommentContainer">
                <div class="replyCommentCount">
                  <span class="fa fa-reply"></span> <span id="comment-replay-count-<?php echo e($comment->id); ?>"><?php echo e(count($comment->HaveReplayCommentPosts)); ?></span> replies
                </div>
                <div class="replyCommentList ">
                  <?php $__currentLoopData = $comment->HaveReplayCommentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $replay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="box-comment">
                    <?php if($replay->FromUser->profile_photo==''): ?>
                    <img class="img-circle img-sm" src="<?php echo e(asset('aji/component/img/Friends/guy-7.jpg')); ?>" alt="User Image">
                    <?php else: ?>
                    <img class="img-circle img-sm" src="<?php echo e(asset($replay->FromUser->profile_photo)); ?>" alt="User Image">

                    <?php endif; ?>
                    <div class="comment-text">
                      <span class="username">
                        <a href="<?php echo e(url('/user/'.$replay->FromUser->id.'/show/timeline')); ?>"><?php echo e($replay->FromUser->username); ?></a>
                        <a href=""><span class="text-muted pull-right">x</span></a>
                      </span>
                      <?php echo e($replay->content); ?>

                      <div class="actionFooterPost">
                        <span class="text-muted"><?php echo e(TimeG::gTime($replay->created_at)); ?></span>
                      </div>
                    </div>
                  </div>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="box-comment">
                    <?php if(Auth::user()->profile_photo!=''): ?>
                    <img class="img-circle img-sm" src="<?php echo e(url(Auth::user()->profile_photo)); ?>" alt="User Image">
                    <?php else: ?>
                    <img class="img-circle img-sm" src="<?php echo e(asset('aji/component/img/Friends/guy-7.jpg')); ?>" alt="User Image">
                    <?php endif; ?>

                    <div class="comment-text">

                      <div class="textAreaReply">
                        <textarea name="" class="form-control input-sm"></textarea>
                        <div class="buttonPostReply">
                          <button class="btn btnReplyImage"><span class="fa fa-camera"></span></button>
                          <button class="btn"><span class="fa fa-paper-plane-o"></span></button>
                          <input type="file" name="fileReply" class="filesReply">
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

              </div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      </div>
      <?php if($post->comment_count > 2): ?>
      <div class="viewAllComment"  class="" onclick="viewAllComment(this)" viewed="hidden"  post-id="<?php echo e($post->id); ?>" style="background: #f6f7f9; padding:10px 0 10px 0px;" >
        <a class="text-capitalize">View all comments</a>
      </div>

      <?php endif; ?>
      <div class="box-footer">
       <?php if(Auth::user()->profile_photo==''): ?>
       <img class="img-responsive img-circle img-sm" src="<?php echo e(asset('aji/component/img/Friends/guy-3.jpg')); ?>" alt="User Image">
       <?php else: ?>
       <img class="img-responsive img-circle img-sm" src="<?php echo e(asset(Auth::user()->profile_photo)); ?>" alt="User Image">

       <?php endif; ?>
       <div class="img-push">
        <div class="textAreaReply">
          <textarea name="" id="input-content-comment-post-<?php echo e($post->id); ?>" class="form-control input-sm writeComment" placeholder="Write a comment.."></textarea>
          <div class="buttonPostReply" style="display: none;" id="spining-send-comment-post-<?php echo e($post->id); ?>">
           <button class="btn " style="" ><i class="fa fa-spinner fa-spin" ></i>
           </button>
         </div>
         <div class="buttonPostReply" id="btn-send-comment-post-<?php echo e($post->id); ?>">
          <button class="btn btnReplyImage"><span class="fa fa-camera"></span></button>
          <button class="btn" onclick="commentPostPublishEvent(<?php echo e($post->id); ?>)" ><span class="fa fa-paper-plane-o"></span>
          </button>
          <input type="file" name="fileReply" class="filesReply">
        </div>
      </div>
    </div>
  </div>
</div><!-- end post -->



<div class="modal fade" id="modal-share-post-<?php echo e($post->id); ?>" tabindex="-1" role="dialog" aria-labelledby="modal-share">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="modal-share"> Share on your timeline</h4>
      </div>
      <div class="modal-body text-centers">

        <div class="box profile-info n-border-top">
          <form>
            <textarea class="form-control input-lg p-text-area" id="textareaPostShare" placeholder="Say something about this.."></textarea>
          </form>
          <div class="postQuote">
            <div class="imagePost" style="height: 300px;">
              <?php if(count($post->HavePostFilePictures)>1): ?>
              <img class="img-responsive pad" src="<?php echo e(url($post->HavePostFilePictures[0]['url'])); ?>" alt="Photo" style=" ">

              <?php else: ?>
              <?php $__currentLoopData = $post->HavePostFilePictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <img class="img-responsive pad" src="<?php echo e(url($picture->url)); ?>" alt="Photo" style=" ">
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </div>
            <div class="quotePostText">
              <blockquote>
                <span class="username"><a href="#"><?php echo e($post->FromUser->name); ?></a></span><br>
                <span class="text-muted"><?php echo e(Carbon\Carbon::parse($post->created_at)->diffForHumans()); ?> - <a href="#">
                  <?php if($post->kanal=='national'): ?>
                  National

                  <?php else: ?>
                  <?php echo e($post->FromCity->name); ?>

                  <?php endif; ?>

                </a></span>
                <p><?php echo e($post->content); ?></p>
              </blockquote>
            </div>
          </div>
          <div class="box-footer box-form" id="boxFormPost">
            <button type="button" class="btn btn-azure pull-right" id="buttonPostStatusShare">Post</button>
            <ul class="nav nav-pills">
              <li>
                <select name="channelPost" id="channelPost" class="form-control" name="kanal">
                  <option value="0">National</option>
                  <option value="2">Kota</option>
                </select>
              </li>
            </ul>
          </div>
        </div><!-- end post state form -->
      </div>
    </div>
  </div>
</div>


<div id="modal-likes-<?php echo e($post->id); ?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><?php echo e($post->like_count); ?></span> likes</h4>
        
      </div>
      <div class="modal-body">
        <div class="table-responsive">
          <table class="table user-list">
            <tbody>
              <?php $__currentLoopData = $post->HavePostLikes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td>
                  <?php if($like->FromUser->profile_photo!=''): ?>
                  <img src="<?php echo e($like->FromUser->profile_photo); ?>" alt="" class="img-circle img-no-padding img-responsive" style="width: 40px; height: 40px;">
                  <?php else: ?>
                  <img src="<?php echo e(url('aji/component/img/Friends/guy-2.jpg')); ?>" alt="" class="img-circle img-no-padding img-responsive" style="width: 40px; height: 40px;">
                  <?php endif; ?>
                  <a href="#" class="user-link"><?php echo e($like->FromUser->username); ?></a>
                  <!-- <span class="user-subhead">Ketua Umum</span> -->
                </td>
                <td>
                  <a href="messages.html" class="btn btn-azure pull-right">Message
                  </a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
        </div>
        <div class="modal-footer">
        </div>
      </div>

    </div>
  </div>





