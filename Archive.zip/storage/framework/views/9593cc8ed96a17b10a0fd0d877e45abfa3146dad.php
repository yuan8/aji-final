<script type="text/javascript">
	
	
function Login(){
	Link="<?php echo e(url('home')); ?>";
	VisiteLink(Link);
}

	
</script>