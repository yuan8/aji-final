<!DOCTYPE html>
<html>
<head>
    <script type="text/javascript">
        
    var URL_THIS="<?php echo e(url('')); ?>";

    </script>
    <?php echo $__env->make('component.header-app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('component.component-connect', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body class="animated fadeIn">

	<?php echo $__env->make('component.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('component.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body >
	<script src="<?php echo e(asset('aji/component/bootstrap.3.3.6/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('aji/component/assets/js/jquery.sticky-kit.js')); ?>"></script>
    <script src="<?php echo e(asset('aji/component/assets/js/script.js')); ?>"></script>
    <script src="<?php echo e(asset('aji/component/assets/chosen/chosen.jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('aji/component/assets/jquery.bxslider/jquery.bxslider.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('aji/connect.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('aji/component/toogle/css/bootstrap-toggle.css')); ?>">
    
    <script type="text/javascript" src="<?php echo e(asset('aji/component/toogle/js/bootstrap-toggle.js')); ?>"></script>

    <?php echo $__env->yieldContent('js'); ?>


    <form  action="<?php echo e(url('logout')); ?>" method="post" id="log-out-service">
    	<?php echo e(csrf_field()); ?>


    </form>

    <script type="text/javascript">
    	
    	function LogOutService(){
    		$('#log-out-service').submit();
    	}

    </script>

</html>
