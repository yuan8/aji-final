<div class="row">
  <div class="col-md-12">
    <div class="cover profile">
      <div class="wrapper">
        <div class="image">
       
          <img src="<?php echo e(asset('aji/component/img/Cover/profile-cover.jpg')); ?>" class="show-in-modal" alt="people">

        </div>

        <?php if($user->id==Auth::user()->id): ?>

          <div class="buttonEditCover">
                  <a href="#" class="btn">
                    <i class="fa fa-camera"></i> Change Cover
                  </a>
                </div>
        <?php endif; ?>

      </div>
      <div class="cover-info">
        <form id="posting-upload-avatar" style="display: none;" enctype="multipart/form-data" action="<?php echo e(url('user/upload/avatar')); ?>" method="post">
         <?php echo e(csrf_field()); ?>


          <input type="file" id="avatar-change" name="avatar" accept="image/*">
        </form>
        <div class="avatar">
        <?php if($user->profile_photo!=''): ?>
        <img src="<?php echo e(asset($user->profile_photo)); ?>" class="img-responsive" style="">

        <?php else: ?>
      <img src="<?php echo e(asset('storage/user/16/photos/c74d958d-609-66940.jpg')); ?>" class="img-responsive" style="">
      <?php endif; ?>
          <?php if($user->id==Auth::user()->id): ?>
            <div class="buttonEditPhoto" >
                <a href="#" class="btn" id="button-change-avatar-profile" >
                    <i class="fa fa-camera"></i>
                </a>
            </div>

            <script type="text/javascript">
              $('#button-change-avatar-profile').click(function(){
                $('#avatar-change').click();
              });

            </script>


        

          <!-- Modal -->
         
          <?php endif; ?>


        </div>
        <div class="name">
          <a href="#"><h1><?php echo e($user->name); ?>

           <!--< span class="username-small">(<?php echo e($user->username); ?>)</span> -->
         </h1></a>
          <div class="text-white">Sekertaris Ariel Noah</div>
        </div>
        <ul class="cover-nav">
          <li 
          <?php if($menu=='timeline'): ?>
          class="active"
          <?php endif; ?>
          > 
             <a href="<?php echo e(url('user/'.$user->id.'/show/timeline')); ?>"><i class="fa fa-fw fa-bars"></i> Timeline</a></li>
          <li
          <?php if($menu=='photos'): ?>
          class="active"
          <?php endif; ?>

          ><a href="<?php echo e(url('user/'.$user->id.'/show/photos')); ?>"><i class="fa fa-fw fa-image"></i> Photos</a></li>
        </ul>

        <?php if($user->id == Auth::user()->id): ?>
        <ul class="cover-nav coverButtonRight pull-right">

          <li>
            <a href="<?php echo e(url('user/'.Auth::user()->id.'/about-edit')); ?>" class="btn btn-azure pull-right">Edit Profile</a>
          </li>
          <li>
            <a href="#" class="btn btn-azure pull-right">Activity Log</a>
          </li>
        </ul>
        <?php else: ?>
        
        <ul class="cover-nav coverButtonRight pull-right">
          <li>
            <a href="messages.html" class="btn btn-azure pull-right">Send Message</a>
          </li>
        </ul>
        <?php endif; ?>

      </div>
    </div>
  </div>
</div>

<?php echo $__env->make('component.modal-upload-avatar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
