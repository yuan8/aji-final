<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Begin page content -->
<<div class="container page-content page-events ">
       <h3 style="margin-top:0; text-align:center;">Event History</h3>

      <div class="row">
        <div class="col-md-12">
          <div class="row events">
              <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-md-4">
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <div class="media">
                          <img src="<?php echo e(asset('aji/component/img/Photos/2.jpg')); ?>" alt="">
                        </div>
                      </div>
                      <div class="panel-body">
                        <h4 class="media-heading margin-v-5"><a href="#"><?php echo e($event->title); ?></a></h4>
                        <ul class="event-deskripsi-list">
                          <li class="eventdate"><i class="fa fa-calendar-o"></i> <?php echo e(TimeG::gTime($event->time)); ?></li>
                          <li class="eventlokasi"><a href="#" target="_blank"><i class="fa fa-map-marker"></i><?php echo e($event->address); ?></a></li>
                          <li class="eventjoined"><i class="fa fa-check"></i> <?php echo e($event->joined_count); ?> peoples joined</li>
                        </ul>
                        <p class="common-events">
                         <?php echo e($event->content); ?>

                        </p>
                      </div>
                    </div>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div><!-- end left posts-->
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">
  function postNewPost(){
    $('#postNewPost').submit();
  }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>